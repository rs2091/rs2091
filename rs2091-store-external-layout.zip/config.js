window.RS2091_CONFIG = {
  supabaseUrl: 'https://lcicozsjdbuivwlfldnb.supabase.co',
  supabasePublishableKey: 'sb_publishable_28eD8kfGGXZVBBky1f2gow_DDtwMZMC'
};
