(() => {
  'use strict';

  const cfg = window.RS2091_CONFIG;
  if (!cfg?.supabaseUrl || !cfg?.supabasePublishableKey) {
    console.error('RS2091_CONFIG is missing.');
    return;
  }

  const state = {
    products: [],
    inventory: [],
    reviews: [],
    news: [],
    settings: null,
    currentProduct: null,
    selectedVariant: null,
    cart: loadJSON('rs2091_cart', []),
    session: loadJSON('rs2091_session', null),
    user: null,
    isAdmin: false,
    adminTab: 'products',
    adminProducts: [],
    adminInventory: [],
    adminReviews: [],
    adminNews: [],
    adminSettings: null,
    editingProductId: null,
    editingReviewId: null,
    editingNewsId: null,
  };

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  function loadJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  }
  function saveJSON(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
  function money(n) { return `¥${Number(n || 0).toLocaleString('ja-JP')}`; }
  function escapeHTML(value = '') {
    return String(value)
      .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
  }
  function safeUrl(url = '') {
    const s = String(url || '').trim();
    if (s.startsWith('/')) return s;
    try {
      const u = new URL(s);
      if (u.protocol === 'https:' || u.protocol === 'http:') return u.href;
    } catch {}
    return '/assets/tee-placeholder.svg';
  }
  function safeExternalUrl(url = '') {
    const value = String(url || '').trim();
    if (!value) return '';
    try {
      const parsed = new URL(value);
      return parsed.protocol === 'https:' ? parsed.href : '';
    } catch { return ''; }
  }
  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : new Intl.DateTimeFormat('ja-JP', { year:'numeric', month:'2-digit', day:'2-digit' }).format(date).replaceAll('/', '.');
  }
  function setCopy(id, value, fallback = '') {
    const element = $(`#${id}`);
    if (element) element.textContent = value || fallback;
  }
  function setDisplayTitle(id, value, fallback = '') {
    const element = $(`#${id}`);
    if (element) element.innerHTML = escapeHTML(value || fallback).trim().replace(/\r?\n/g, '<br>');
  }
  function toast(message, timeout = 2600) {
    const el = $('#toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove('show'), timeout);
  }
  function setSession(session) {
    state.session = session || null;
    if (session) saveJSON('rs2091_session', session);
    else localStorage.removeItem('rs2091_session');
  }
  function authHeaders(extra = {}) {
    const headers = { apikey: cfg.supabasePublishableKey, ...extra };
    if (state.session?.access_token) headers.Authorization = `Bearer ${state.session.access_token}`;
    return headers;
  }

  async function api(path, options = {}) {
    const { method = 'GET', body, headers = {}, raw = false, allowRefresh = true } = options;
    const finalHeaders = authHeaders(headers);
    let payload = body;
    if (body !== undefined && body !== null && !(body instanceof Blob) && !(body instanceof File)) {
      finalHeaders['Content-Type'] ??= 'application/json';
      payload = typeof body === 'string' ? body : JSON.stringify(body);
    }
    let res = await fetch(`${cfg.supabaseUrl}${path}`, { method, headers: finalHeaders, body: payload });
    if (res.status === 401 && allowRefresh && state.session?.refresh_token) {
      const refreshed = await refreshSession();
      if (refreshed) return api(path, { ...options, allowRefresh: false });
    }
    if (!res.ok) {
      let detail = `${res.status} ${res.statusText}`;
      try {
        const err = await res.json();
        detail = err.message || err.msg || err.error_description || err.hint || detail;
      } catch {}
      throw new Error(detail);
    }
    if (raw) return res;
    if (res.status === 204) return null;
    const text = await res.text();
    if (!text) return null;
    try { return JSON.parse(text); } catch { return text; }
  }

  async function refreshSession() {
    try {
      const res = await fetch(`${cfg.supabaseUrl}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { apikey: cfg.supabasePublishableKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: state.session.refresh_token }),
      });
      if (!res.ok) throw new Error('refresh failed');
      const data = await res.json();
      setSession(data);
      return true;
    } catch {
      setSession(null);
      state.user = null;
      state.isAdmin = false;
      return false;
    }
  }

  async function loadStore() {
    try {
      const [products, inventory, reviews, news, settings] = await Promise.all([
        api('/rest/v1/rs2091_products?select=*&order=featured.desc,created_at.asc'),
        api('/rest/v1/rs2091_inventory?select=*&order=size.asc'),
        api('/rest/v1/rs2091_reviews?select=*&order=created_at.desc'),
        api('/rest/v1/rs2091_news?select=*&order=published_at.desc,created_at.desc'),
        api('/rest/v1/rs2091_store_settings?select=*&id=eq.1&limit=1'),
      ]);
      state.products = products || [];
      state.inventory = inventory || [];
      state.reviews = reviews || [];
      state.news = news || [];
      state.settings = settings?.[0] || null;
      if ($('#productGrid')) renderStore();
    } catch (err) {
      console.error(err);
      if ($('#productGrid')) $('#productGrid').innerHTML = `<div class="empty-state">ショップデータを読み込めませんでした。<br><small>${escapeHTML(err.message)}</small></div>`;
    }
  }

  function renderStore() {
    const s = state.settings;
    if (s) {
      setCopy('announcement', s.announcement, 'rs2091 / OFFICIAL ONLINE STORE');
      setCopy('heroEyebrow', s.hero_eyebrow, 'DROP 001 / TOKYO');
      setDisplayTitle('heroTitle', s.hero_title, 'UNIFORM\nFOR AFTER\nHOURS.');
      setCopy('heroCopy', s.hero_copy, '余白、重さ、着心地。毎日着るために削ぎ落とした rs2091 のTシャツ。');
      setCopy('heroCta', s.hero_cta, 'VIEW THE DROP');
      setCopy('shopEyebrow', s.shop_eyebrow, 'CURRENT DROP');
      setCopy('shopTitle', s.shop_title, 'SHOP ALL');
      setCopy('newsEyebrow', s.news_eyebrow, 'LATEST UPDATE');
      setCopy('newsTitle', s.news_title, 'NEWS');
      setCopy('manifestoKicker', s.manifesto_kicker, 'rs2091 / STANDARD 01');
      setDisplayTitle('manifestoTitle', s.manifesto_title, 'LESS NOISE.\nBETTER WEIGHT.\nWEAR IT OFTEN.');
      setCopy('manifestoNote1', s.manifesto_note_1, '01 / COTTON FIRST');
      setCopy('manifestoNote2', s.manifesto_note_2, '02 / RELAXED FORM');
      setCopy('manifestoNote3', s.manifesto_note_3, '03 / SMALL RUNS');
      setCopy('aboutEyebrow', s.about_eyebrow, 'ABOUT');
      setDisplayTitle('aboutTitle', s.about_title, 'MADE FOR\nREPEAT WEAR.');
      setCopy('aboutCopy', s.about_copy, 'rs2091は、日常のノイズを減らすための小さなTシャツレーベル。シルエットと生地感を主役にした、長く着られる定番を作ります。');
      setCopy('shippingTitle', s.shipping_title, 'SHIPPING');
      setCopy('shippingCopy', s.shipping_copy, '');
      setCopy('sizeTitle', s.size_title, 'SIZE');
      setCopy('sizeCopy', s.size_copy, '');
      setCopy('reviewTitle', s.review_title, 'REVIEW');
      setCopy('reviewCopy', s.review_copy, '');
      setCopy('instagramHandle', s.instagram_handle, '@rs2091');
      setCopy('siteBrand', s.site_brand, 'rs2091');
      setCopy('footerBrand', s.site_brand, 'rs2091');
      setCopy('footerCopy', s.footer_copy, '');
      setCopy('navShopLabel', s.nav_shop_label, 'SHOP');
      setCopy('navNewsLabel', s.nav_news_label, 'NEWS');
      setCopy('navAboutLabel', s.nav_about_label, 'ABOUT');
      setCopy('navGuideLabel', s.nav_guide_label, 'GUIDE');
      setCopy('cartNote', s.cart_note, '外部販売リンクが設定された商品は、商品ページまたは一覧のボタンから販売サイトへ移動できます。');
      document.title = s.page_title || 'rs2091 — Official Store';
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription && s.page_description) metaDescription.setAttribute('content', s.page_description);
      applyHomeLayout(s);
    } else {
      applyHomeLayout({});
    }
    $('#productCount').textContent = state.products.length;
    $('#productEmpty').classList.toggle('hidden', state.products.length > 0);
    $('#productGrid').innerHTML = state.products.map(productCard).join('');
    $$('.product-card').forEach(card => {
      card.addEventListener('click', e => { if (!e.target.closest('[data-external-purchase]')) openProduct(card.dataset.id); });
      card.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && !e.target.closest('[data-external-purchase]')) { e.preventDefault(); openProduct(card.dataset.id); } });
    });
    $$('[data-external-purchase]').forEach(link => link.addEventListener('click', e => e.stopPropagation()));
    renderNews();
    renderCart();
  }

  function applyHomeLayout(s = {}) {
    const body = document.body;
    const width = ['compact','standard','wide'].includes(s.content_width) ? s.content_width : 'standard';
    const align = ['left','center'].includes(s.hero_align) ? s.hero_align : 'left';
    const preset = ['standard','shop_first','story_first'].includes(s.layout_preset) ? s.layout_preset : 'standard';
    const columns = [2,3,4].includes(Number(s.product_columns)) ? Number(s.product_columns) : 4;
    body.dataset.contentWidth = width;
    body.dataset.heroAlign = align;
    body.dataset.layoutPreset = preset;
    body.style.setProperty('--product-columns', String(columns));

    const visible = {
      news: s.show_news !== false,
      manifesto: s.show_manifesto !== false,
      about: s.show_about !== false,
      guide: s.show_guide !== false,
    };
    for (const [id, isVisible] of Object.entries(visible)) {
      document.getElementById(id)?.classList.toggle('hidden', !isVisible);
      document.querySelector(`[data-nav-section="${id}"]`)?.classList.toggle('hidden', !isVisible);
      document.querySelector(`[data-footer-section="${id}"]`)?.classList.toggle('hidden', !isVisible);
    }

    const orders = {
      standard: { hero:10, shop:20, news:30, manifesto:40, about:50, guide:60 },
      shop_first: { shop:10, hero:20, news:30, manifesto:40, about:50, guide:60 },
      story_first: { hero:10, manifesto:20, about:30, shop:40, news:50, guide:60 },
    }[preset];
    for (const [id, order] of Object.entries(orders)) {
      const el = document.getElementById(id);
      if (el) el.style.order = String(order);
    }
  }

  function renderNews() {
    $('#newsCount').textContent = state.news.length;
    $('#newsEmpty').classList.toggle('hidden', state.news.length > 0);
    $('#newsGrid').innerHTML = state.news.map(item => `
      <article class="news-card" data-news-id="${escapeHTML(item.id)}" tabindex="0" aria-label="${escapeHTML(item.title)}">
        <div class="news-date">${formatDate(item.published_at || item.created_at)}</div>
        <h3>${escapeHTML(item.title)}</h3>
        <p>${escapeHTML(item.summary || '')}</p>
        <span class="news-more">READ MORE ↗</span>
      </article>`).join('');
    $$('[data-news-id]').forEach(card => {
      const open = () => openNews(card.dataset.newsId);
      card.addEventListener('click', open);
      card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
  }

  function openNews(id) {
    const item = state.news.find(x => x.id === id);
    if (!item) return;
    $('#newsDialogBody').innerHTML = `<article class="news-detail">
      <p class="eyebrow">NEWS / ${formatDate(item.published_at || item.created_at)}</p>
      <h2>${escapeHTML(item.title)}</h2>
      ${item.summary ? `<p class="news-detail-summary">${escapeHTML(item.summary)}</p>` : ''}
      <div class="news-detail-body">${escapeHTML(item.body || '')}</div>
    </article>`;
    $('#newsDialog').showModal();
  }

  function productCard(p) {
    const stock = state.inventory.filter(v => v.product_id === p.id).reduce((a, v) => a + Number(v.stock || 0), 0);
    const purchaseUrl = safeExternalUrl(p.purchase_url);
    const purchaseLabel = String(p.purchase_label || 'VIEW ITEM').trim() || 'VIEW ITEM';
    return `
      <article class="product-card" data-id="${escapeHTML(p.id)}" tabindex="0" aria-label="${escapeHTML(p.name)}">
        <div class="product-image-wrap">
          <img class="product-image" src="${escapeHTML(safeUrl(p.image_url))}" alt="${escapeHTML(p.name)}" loading="lazy">
          ${p.featured ? '<span class="product-badge">FEATURED</span>' : stock <= 0 ? '<span class="product-badge">SOLD OUT</span>' : ''}
        </div>
        <div class="product-info">
          <div class="product-row">
            <div>
              <div class="product-name">${escapeHTML(p.name)}</div>
              <div class="product-sub">${escapeHTML(p.subtitle)}</div>
            </div>
            <div class="product-price">${p.compare_at_price ? `<del>${money(p.compare_at_price)}</del>` : ''}${money(p.price)}</div>
          </div>
          ${purchaseUrl ? `<a class="product-external-button" data-external-purchase href="${escapeHTML(purchaseUrl)}" target="_blank" rel="noopener noreferrer">${escapeHTML(purchaseLabel)} <span>↗</span></a>` : ''}
        </div>
      </article>`;
  }

  function openProduct(id) {
    const p = state.products.find(x => x.id === id);
    if (!p) return;
    state.currentProduct = p;
    const variants = state.inventory.filter(v => v.product_id === p.id);
    state.selectedVariant = variants.find(v => v.stock > 0) || null;
    renderProductDialog();
    $('#productDialog').showModal();
  }

  function renderProductDialog() {
    const p = state.currentProduct;
    if (!p) return;
    const variants = state.inventory.filter(v => v.product_id === p.id);
    const reviews = state.reviews.filter(r => r.product_id === p.id && r.status === 'published');
    const avg = reviews.length ? (reviews.reduce((a, r) => a + Number(r.rating), 0) / reviews.length).toFixed(1) : '—';
    const color = variants[0]?.color || '';
    const purchaseUrl = safeExternalUrl(p.purchase_url);
    const purchaseLabel = String(p.purchase_label || 'VIEW ITEM').trim() || 'VIEW ITEM';
    const sizes = ['S','M','L','XL','XXL'];
    const variantBySize = Object.fromEntries(variants.map(v => [v.size.toUpperCase(), v]));
    $('#productDialogBody').innerHTML = `
      <div class="product-detail">
        <div class="detail-image-wrap"><img class="detail-image" src="${escapeHTML(safeUrl(p.image_url))}" alt="${escapeHTML(p.name)}"></div>
        <div class="detail-copy">
          <p class="eyebrow">RS2091 / ${escapeHTML(p.slug)}</p>
          <h2>${escapeHTML(p.name)}</h2>
          <div class="detail-sub">${escapeHTML(p.subtitle)}</div>
          <div class="detail-price">${p.compare_at_price ? `<del>${money(p.compare_at_price)}</del> &nbsp;` : ''}${money(p.price)}</div>
          <p class="detail-description">${escapeHTML(p.description)}</p>
          <div class="variant-label"><span>COLOR</span><span>${escapeHTML(color || '—')}</span></div>
          <div class="variant-label"><span>SIZE</span><span>SELECT</span></div>
          <div class="size-grid">
            ${sizes.map(size => {
              const v = variantBySize[size];
              const selected = state.selectedVariant?.id === v?.id;
              return `<button type="button" class="size-button ${selected ? 'selected' : ''}" data-variant="${escapeHTML(v?.id || '')}" ${!v || v.stock <= 0 ? 'disabled' : ''}>${size}</button>`;
            }).join('')}
          </div>
          ${purchaseUrl
            ? `<a class="primary-button stores-button" href="${escapeHTML(purchaseUrl)}" target="_blank" rel="noopener noreferrer">${escapeHTML(purchaseLabel)}</a>
               <div class="stock-note">購入・決済・配送条件はリンク先の販売サイトで確認してください。</div>`
            : `<button id="addCartButton" type="button" class="primary-button add-cart" ${!state.selectedVariant ? 'disabled' : ''}>ADD TO CART — ${money(p.price)}</button>
               <div class="stock-note">${state.selectedVariant ? `選択中: ${escapeHTML(state.selectedVariant.size)} / 在庫 ${state.selectedVariant.stock}` : '現在選択可能な在庫がありません'}</div>`}
          <div class="detail-divider"></div>
          <div class="review-summary"><span>REVIEWS</span><strong>${avg} / 5</strong><span>(${reviews.length})</span></div>
          <div class="review-list">
            ${reviews.length ? reviews.map(reviewCard).join('') : '<p class="review-body">まだ公開レビューはありません。</p>'}
          </div>
          <form id="reviewForm" class="review-form">
            <p class="eyebrow" style="margin:18px 0 0">WRITE A REVIEW</p>
            <div class="review-form-grid">
              <input class="form-control" name="author_name" maxlength="80" placeholder="お名前 / ニックネーム" required>
              <select class="form-control" name="rating" required>
                <option value="5">★★★★★ 5</option><option value="4">★★★★☆ 4</option><option value="3">★★★☆☆ 3</option><option value="2">★★☆☆☆ 2</option><option value="1">★☆☆☆☆ 1</option>
              </select>
            </div>
            <input class="form-control" name="title" maxlength="100" placeholder="タイトル">
            <textarea class="form-control" name="body" maxlength="1200" placeholder="レビュー本文" required></textarea>
            <button class="secondary-button" type="submit">SUBMIT REVIEW</button>
          </form>
        </div>
      </div>`;
    $$('.size-button', $('#productDialogBody')).forEach(btn => btn.addEventListener('click', () => {
      state.selectedVariant = variants.find(v => v.id === btn.dataset.variant) || null;
      renderProductDialog();
    }));
    $('#addCartButton')?.addEventListener('click', addCurrentToCart);
    $('#reviewForm')?.addEventListener('submit', submitReview);
  }

  function reviewCard(r) {
    return `<article class="review-card">
      <div class="review-card-head"><span>${'★'.repeat(Number(r.rating))}${'☆'.repeat(5 - Number(r.rating))}</span><span>${escapeHTML(r.author_name)}</span></div>
      <div class="review-title">${escapeHTML(r.title || 'Review')}</div>
      <p class="review-body">${escapeHTML(r.body)}</p>
    </article>`;
  }

  async function submitReview(e) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = {
      product_id: state.currentProduct.id,
      author_name: String(form.get('author_name') || '').trim(),
      rating: Number(form.get('rating')),
      title: String(form.get('title') || '').trim(),
      body: String(form.get('body') || '').trim(),
      status: 'pending',
    };
    try {
      await api('/rest/v1/rs2091_reviews', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: payload });
      e.currentTarget.reset();
      toast('レビューを受け付けました。確認後に公開されます。');
    } catch (err) { toast(`送信できませんでした: ${err.message}`); }
  }

  function addCurrentToCart() {
    const p = state.currentProduct;
    const v = state.selectedVariant;
    if (!p || !v || v.stock <= 0) return;
    const key = `${p.id}:${v.id}`;
    const existing = state.cart.find(x => x.key === key);
    if (existing) {
      if (existing.qty >= v.stock) return toast('選択サイズの在庫上限です。');
      existing.qty += 1;
    } else {
      state.cart.push({ key, productId:p.id, variantId:v.id, name:p.name, image_url:p.image_url, price:p.price, size:v.size, color:v.color, sku:v.sku, qty:1, maxStock:v.stock });
    }
    saveJSON('rs2091_cart', state.cart);
    renderCart();
    toast('カートに追加しました。');
  }

  function renderCart() {
    const count = state.cart.reduce((a, x) => a + x.qty, 0);
    $('#cartCount').textContent = count;
    $('#cartItems').innerHTML = state.cart.length ? state.cart.map(item => `
      <div class="cart-item" data-key="${escapeHTML(item.key)}">
        <img src="${escapeHTML(safeUrl(item.image_url))}" alt="${escapeHTML(item.name)}">
        <div>
          <div class="cart-item-name">${escapeHTML(item.name)}</div>
          <div class="cart-item-meta">${escapeHTML(item.color)} / ${escapeHTML(item.size)}<br>${escapeHTML(item.sku)}</div>
          <div class="cart-item-controls">
            <button class="qty-btn" data-action="minus" type="button">−</button><span>${item.qty}</span><button class="qty-btn" data-action="plus" type="button">＋</button>
            <button class="cart-remove" data-action="remove" type="button">REMOVE</button>
          </div>
        </div>
        <div class="cart-item-price">${money(item.price * item.qty)}</div>
      </div>`).join('') : '<div class="cart-empty">CART IS EMPTY<br>商品を選択してください。</div>';
    const total = state.cart.reduce((a, x) => a + x.price * x.qty, 0);
    $('#cartTotal').textContent = money(total);
    $$('.cart-item').forEach(row => row.addEventListener('click', e => {
      const action = e.target.dataset.action;
      if (!action) return;
      const item = state.cart.find(x => x.key === row.dataset.key);
      if (!item) return;
      if (action === 'plus' && item.qty < item.maxStock) item.qty++;
      if (action === 'minus') item.qty--;
      if (action === 'remove' || item.qty <= 0) state.cart = state.cart.filter(x => x.key !== item.key);
      saveJSON('rs2091_cart', state.cart); renderCart();
    }));
  }

  function openCart() {
    $('#cartDrawer').classList.add('open');
    $('#cartDrawer').setAttribute('aria-hidden', 'false');
    $('#cartBackdrop').classList.remove('hidden');
  }
  function closeCart() {
    $('#cartDrawer').classList.remove('open');
    $('#cartDrawer').setAttribute('aria-hidden', 'true');
    $('#cartBackdrop').classList.add('hidden');
  }
  async function copyOrder() {
    if (!state.cart.length) return toast('カートが空です。');
    const lines = ['rs2091 注文メモ', ''];
    state.cart.forEach(i => lines.push(`${i.name} / ${i.color} / ${i.size} × ${i.qty} — ${money(i.price * i.qty)}`));
    lines.push('', `合計: ${money(state.cart.reduce((a,x)=>a+x.price*x.qty,0))}`);
    try { await navigator.clipboard.writeText(lines.join('\n')); toast('注文内容をコピーしました。'); }
    catch { toast('コピーできませんでした。'); }
  }

  // ---------- Admin auth ----------
  async function openAdmin() {
    $('#adminDialog').showModal();
    await hydrateAdminIdentity();
    renderAdmin();
  }

  async function hydrateAdminIdentity() {
    if (!state.session?.access_token) { state.user = null; state.isAdmin = false; return; }
    try {
      const user = await api('/auth/v1/user');
      state.user = user;
      const rows = await api(`/rest/v1/rs2091_admins?select=user_id&user_id=eq.${encodeURIComponent(user.id)}&limit=1`);
      state.isAdmin = Boolean(rows?.length);
      if (state.isAdmin) await loadAdminData();
    } catch {
      setSession(null); state.user = null; state.isAdmin = false;
    }
  }

  async function login(email, password) {
    const res = await fetch(`${cfg.supabaseUrl}/auth/v1/token?grant_type=password`, {
      method:'POST', headers:{ apikey:cfg.supabasePublishableKey, 'Content-Type':'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error_description || data.msg || data.message || 'ログインできませんでした');
    setSession(data);
    await hydrateAdminIdentity();
  }

  async function signup(email, password) {
    const redirect = encodeURIComponent(location.origin + '/admin/');
    const res = await fetch(`${cfg.supabaseUrl}/auth/v1/signup?redirect_to=${redirect}`, {
      method:'POST', headers:{ apikey:cfg.supabasePublishableKey, 'Content-Type':'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.msg || data.message || '登録できませんでした');
    if (data.access_token) { setSession(data); await hydrateAdminIdentity(); return '登録・ログインしました。'; }
    return '確認メールを送信しました。メール確認後にログインしてください。';
  }

  async function claimAdmin(code) {
    const result = await api('/rest/v1/rpc/rs2091_claim_admin', { method:'POST', body:{ p_setup_code: code } });
    if (result !== true) throw new Error('セットアップコードが一致しません。');
    await hydrateAdminIdentity();
  }

  function renderAdmin(message = '') {
    const root = $('#adminRoot');
    if (!state.user) {
      root.innerHTML = `
        <div class="admin-auth-wrap"><div class="admin-auth-card">
          <h3>ADMIN LOGIN</h3>
          <p>Supabase Authを使った管理者ログインです。初回だけアカウント作成後、セットアップコードで管理者権限を取得します。</p>
          ${message ? `<div class="admin-message">${escapeHTML(message)}</div>` : ''}
          <form id="adminAuthForm" class="admin-form">
            <label>EMAIL</label><input class="form-control" type="email" name="email" autocomplete="email" required>
            <label>PASSWORD</label><input class="form-control" type="password" name="password" minlength="8" autocomplete="current-password" required>
            <div class="admin-form-actions">
              <button class="primary-button" type="submit" data-auth="login">LOGIN</button>
              <button class="secondary-button" type="button" id="signupButton">CREATE ACCOUNT</button>
            </div>
          </form>
        </div></div>`;
      $('#adminAuthForm').addEventListener('submit', async e => {
        e.preventDefault(); const fd = new FormData(e.currentTarget);
        try { await login(fd.get('email'), fd.get('password')); renderAdmin(); }
        catch (err) { renderAdmin(err.message); }
      });
      $('#signupButton').addEventListener('click', async () => {
        const form = $('#adminAuthForm'); if (!form.reportValidity()) return;
        const fd = new FormData(form);
        try { const msg = await signup(fd.get('email'), fd.get('password')); renderAdmin(msg); }
        catch (err) { renderAdmin(err.message); }
      });
      return;
    }

    if (!state.isAdmin) {
      root.innerHTML = `
        <div class="admin-auth-wrap"><div class="admin-auth-card">
          <h3>CLAIM ADMIN</h3>
          <p><strong>${escapeHTML(state.user.email || '')}</strong> でログイン中です。初回管理者セットアップコードを入力してください。</p>
          ${message ? `<div class="admin-message error">${escapeHTML(message)}</div>` : ''}
          <form id="claimAdminForm" class="admin-form">
            <label>SETUP CODE</label><input class="form-control" type="password" name="code" required>
            <button class="primary-button" type="submit">ACTIVATE ADMIN</button>
            <button class="secondary-button" id="adminLogoutClaim" type="button">LOGOUT</button>
          </form>
        </div></div>`;
      $('#claimAdminForm').addEventListener('submit', async e => {
        e.preventDefault();
        try { await claimAdmin(new FormData(e.currentTarget).get('code')); renderAdmin(); }
        catch (err) { renderAdmin(err.message); }
      });
      $('#adminLogoutClaim').addEventListener('click', logoutAdmin);
      return;
    }
    renderAdminDashboard();
  }

  async function logoutAdmin() {
    try { await api('/auth/v1/logout', { method:'POST' }); } catch {}
    setSession(null); state.user=null; state.isAdmin=false; renderAdmin('ログアウトしました。');
  }

  async function loadAdminData() {
    const [products, inventory, reviews, news, settings] = await Promise.all([
      api('/rest/v1/rs2091_products?select=*&order=created_at.desc'),
      api('/rest/v1/rs2091_inventory?select=*&order=updated_at.desc'),
      api('/rest/v1/rs2091_reviews?select=*&order=created_at.desc'),
      api('/rest/v1/rs2091_news?select=*&order=created_at.desc'),
      api('/rest/v1/rs2091_store_settings?select=*&id=eq.1&limit=1'),
    ]);
    state.adminProducts = products || [];
    state.adminInventory = inventory || [];
    state.adminReviews = reviews || [];
    state.adminNews = news || [];
    state.adminSettings = settings?.[0] || null;
  }

  function renderAdminDashboard() {
    const root = $('#adminRoot');
    const totalStock = state.adminInventory.reduce((a,v)=>a+Number(v.stock||0),0);
    const lowStock = state.adminInventory.filter(v=>Number(v.stock)<=Number(v.low_stock_threshold)).length;
    const pending = state.adminReviews.filter(r=>r.status==='pending').length;
    root.innerHTML = `
      <div class="admin-dashboard-head">
        <div class="admin-user">SIGNED IN<br>${escapeHTML(state.user.email || '')}</div>
        <button id="adminLogout" class="mini-button" type="button">LOGOUT</button>
      </div>
      <div class="admin-kpis">
        <div class="kpi"><span>PRODUCTS</span><strong>${state.adminProducts.length}</strong></div>
        <div class="kpi"><span>NEWS</span><strong>${state.adminNews.length}</strong></div>
        <div class="kpi"><span>TOTAL STOCK</span><strong>${totalStock}</strong></div>
        <div class="kpi"><span>LOW STOCK</span><strong>${lowStock}</strong></div>
        <div class="kpi"><span>PENDING REVIEWS</span><strong>${pending}</strong></div>
      </div>
      <div class="admin-tabs">
        ${[['products','PRODUCTS'],['news','NEWS'],['inventory','INVENTORY'],['reviews','REVIEWS'],['settings','SETTINGS']].map(([k,l])=>`<button class="admin-tab ${state.adminTab===k?'active':''}" data-tab="${k}" type="button">${l}</button>`).join('')}
      </div>
      <div id="adminSection" class="admin-section"></div>`;
    $('#adminLogout').addEventListener('click', logoutAdmin);
    $$('.admin-tab').forEach(btn=>btn.addEventListener('click',()=>{state.adminTab=btn.dataset.tab; renderAdminDashboard();}));
    if (state.adminTab === 'products') renderAdminProducts();
    if (state.adminTab === 'news') renderAdminNews();
    if (state.adminTab === 'inventory') renderAdminInventory();
    if (state.adminTab === 'reviews') renderAdminReviews();
    if (state.adminTab === 'settings') renderAdminSettings();
  }

  // ---------- Admin Products ----------
  function renderAdminProducts() {
    const section = $('#adminSection');
    const editing = state.adminProducts.find(p=>p.id===state.editingProductId) || null;
    section.innerHTML = `<div class="admin-grid">
      <div class="admin-list">
        ${state.adminProducts.length ? state.adminProducts.map(p=>`
          <div class="admin-list-row">
            <img class="admin-thumb" src="${escapeHTML(safeUrl(p.image_url))}" alt="">
            <div><div class="admin-row-title">${escapeHTML(p.name)}</div><div class="admin-row-meta">${escapeHTML(p.slug)} / ${money(p.price)} / <span class="status-pill ${escapeHTML(p.status)}">${escapeHTML(p.status)}</span></div></div>
            <div class="admin-row-actions"><button class="mini-button" data-edit-product="${p.id}" type="button">EDIT</button><button class="mini-button danger" data-delete-product="${p.id}" type="button">DELETE</button></div>
          </div>`).join('') : '<div class="admin-message">商品がありません。</div>'}
      </div>
      <form id="productEditor" class="admin-editor">
        <h3>${editing ? 'EDIT PRODUCT' : 'NEW PRODUCT'}</h3>
        <div class="admin-editor-grid">
          <img id="productImagePreview" class="upload-preview" src="${escapeHTML(safeUrl(editing?.image_url || '/assets/tee-placeholder.svg'))}" alt="preview">
          <input type="file" id="productImageFile" class="form-control" accept="image/jpeg,image/png,image/webp,image/avif">
          <input type="hidden" name="image_url" value="${escapeHTML(editing?.image_url || '')}">
          <input class="form-control" name="name" placeholder="商品名" value="${escapeHTML(editing?.name || '')}" required>
          <input class="form-control" name="slug" placeholder="slug" value="${escapeHTML(editing?.slug || '')}" required pattern="[a-z0-9-]+">
          <input class="form-control" name="subtitle" placeholder="240G / BLACK" value="${escapeHTML(editing?.subtitle || '')}">
          <textarea class="form-control" name="description" placeholder="商品説明" required>${escapeHTML(editing?.description || '')}</textarea>
          <input class="form-control" name="purchase_url" type="url" inputmode="url" placeholder="販売先URL（https://...）" value="${escapeHTML(editing?.purchase_url || '')}">
          <input class="form-control" name="purchase_label" maxlength="40" placeholder="購入ボタン文言（VIEW ITEM など）" value="${escapeHTML(editing?.purchase_label || 'VIEW ITEM')}">
          <div class="inline-grid"><input class="form-control" name="price" type="number" min="0" placeholder="価格" value="${editing?.price ?? ''}" required><input class="form-control" name="compare_at_price" type="number" min="0" placeholder="比較価格" value="${editing?.compare_at_price ?? ''}"></div>
          <div class="inline-grid"><select class="form-control" name="status"><option value="active" ${editing?.status==='active'?'selected':''}>active</option><option value="draft" ${editing?.status==='draft'?'selected':''}>draft</option><option value="archived" ${editing?.status==='archived'?'selected':''}>archived</option></select><label class="checkbox-line"><input name="featured" type="checkbox" ${editing?.featured?'checked':''}> FEATURED</label></div>
          <div class="editor-actions"><button class="primary-button" type="submit">${editing?'SAVE':'CREATE'}</button><button id="productEditorReset" class="secondary-button" type="button">CLEAR</button></div>
        </div>
      </form>
    </div>`;
    $$('[data-edit-product]').forEach(btn=>btn.addEventListener('click',()=>{state.editingProductId=btn.dataset.editProduct;renderAdminProducts();}));
    $$('[data-delete-product]').forEach(btn=>btn.addEventListener('click',()=>deleteProduct(btn.dataset.deleteProduct)));
    $('#productEditorReset').addEventListener('click',()=>{state.editingProductId=null;renderAdminProducts();});
    $('#productImageFile').addEventListener('change', e => {
      const file = e.target.files?.[0]; if (file) $('#productImagePreview').src = URL.createObjectURL(file);
    });
    $('#productEditor').addEventListener('submit', saveProduct);
  }

  async function uploadProductImage(file) {
    if (!file) return null;
    if (file.size > 5 * 1024 * 1024) throw new Error('画像は5MB以下にしてください。');
    const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g,'');
    const path = `${Date.now()}-${Math.random().toString(36).slice(2,10)}.${ext}`;
    await api(`/storage/v1/object/rs2091-products/${encodeURIComponent(path)}`, { method:'POST', headers:{ 'Content-Type':file.type, 'x-upsert':'false' }, body:file, raw:true });
    return `${cfg.supabaseUrl}/storage/v1/object/public/rs2091-products/${path}`;
  }

  async function saveProduct(e) {
    e.preventDefault();
    const form = e.currentTarget; const fd = new FormData(form);
    const button = form.querySelector('button[type="submit"]'); button.disabled = true; button.textContent = 'SAVING...';
    try {
      let imageUrl = String(fd.get('image_url') || '');
      const file = $('#productImageFile').files?.[0];
      if (file) imageUrl = await uploadProductImage(file);
      const purchaseUrlInput = String(fd.get('purchase_url') || '').trim();
      const purchaseUrl = safeExternalUrl(purchaseUrlInput);
      if (purchaseUrlInput && !purchaseUrl) throw new Error('販売先URLは https:// から始まるURLを入力してください。');
      const payload = {
        name:String(fd.get('name')).trim(), slug:String(fd.get('slug')).trim().toLowerCase(), subtitle:String(fd.get('subtitle')||'').trim(), description:String(fd.get('description')||'').trim(),
        price:Number(fd.get('price')), compare_at_price:fd.get('compare_at_price') ? Number(fd.get('compare_at_price')) : null,
        image_url:imageUrl, featured:fd.get('featured')==='on', status:String(fd.get('status')),
        purchase_url:purchaseUrl, purchase_label:String(fd.get('purchase_label') || 'VIEW ITEM').trim() || 'VIEW ITEM',
      };
      if (state.editingProductId) await api(`/rest/v1/rs2091_products?id=eq.${state.editingProductId}`, { method:'PATCH', headers:{Prefer:'return=minimal'}, body:payload });
      else await api('/rest/v1/rs2091_products', { method:'POST', headers:{Prefer:'return=minimal'}, body:payload });
      state.editingProductId=null; await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('商品を保存しました。');
    } catch (err) { toast(`保存できません: ${err.message}`); button.disabled=false; button.textContent='SAVE'; }
  }

  async function deleteProduct(id) {
    if (!confirm('この商品を削除しますか？在庫とレビューも連動して削除されます。')) return;
    try { await api(`/rest/v1/rs2091_products?id=eq.${id}`, {method:'DELETE'}); await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('商品を削除しました。'); }
    catch (err) { toast(`削除できません: ${err.message}`); }
  }

  // ---------- Inventory ----------
  function renderAdminInventory() {
    const section = $('#adminSection');
    const productOptions = state.adminProducts.map(p=>`<option value="${p.id}">${escapeHTML(p.name)}</option>`).join('');
    section.innerHTML = `
      <form id="newInventoryForm" class="admin-editor" style="position:static;margin-bottom:18px">
        <h3>ADD VARIANT</h3>
        <div class="inline-grid"><select class="form-control" name="product_id" required><option value="">商品を選択</option>${productOptions}</select><input class="form-control" name="sku" placeholder="SKU" required></div>
        <div class="inline-grid" style="margin-top:8px"><input class="form-control" name="size" placeholder="SIZE" required><input class="form-control" name="color" placeholder="COLOR" required></div>
        <div class="inline-grid" style="margin-top:8px"><input class="form-control" name="stock" type="number" min="0" value="0" required><input class="form-control" name="low_stock_threshold" type="number" min="0" value="3" required></div>
        <button class="primary-button" style="margin-top:8px" type="submit">ADD INVENTORY</button>
      </form>
      <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>PRODUCT</th><th>SKU</th><th>SIZE</th><th>COLOR</th><th>STOCK</th><th>LOW</th><th>ACTION</th></tr></thead><tbody>
        ${state.adminInventory.map(v=>{
          const p=state.adminProducts.find(x=>x.id===v.product_id);
          return `<tr data-inventory-row="${v.id}"><td>${escapeHTML(p?.name||'—')}</td><td><input class="form-control" name="sku" value="${escapeHTML(v.sku)}"></td><td><input class="form-control" name="size" value="${escapeHTML(v.size)}"></td><td><input class="form-control" name="color" value="${escapeHTML(v.color)}"></td><td><input class="form-control" name="stock" type="number" min="0" value="${v.stock}"></td><td><input class="form-control" name="low_stock_threshold" type="number" min="0" value="${v.low_stock_threshold}"></td><td><button class="mini-button" data-save-inventory type="button">SAVE</button> <button class="mini-button danger" data-delete-inventory type="button">DELETE</button></td></tr>`;
        }).join('')}
      </tbody></table></div>`;
    $('#newInventoryForm').addEventListener('submit', createInventory);
    $$('[data-save-inventory]').forEach(btn=>btn.addEventListener('click',()=>saveInventory(btn.closest('tr'))));
    $$('[data-delete-inventory]').forEach(btn=>btn.addEventListener('click',()=>deleteInventory(btn.closest('tr').dataset.inventoryRow)));
  }

  async function createInventory(e) {
    e.preventDefault(); const fd=new FormData(e.currentTarget);
    const payload={product_id:fd.get('product_id'),sku:String(fd.get('sku')).trim(),size:String(fd.get('size')).trim().toUpperCase(),color:String(fd.get('color')).trim().toUpperCase(),stock:Number(fd.get('stock')),low_stock_threshold:Number(fd.get('low_stock_threshold'))};
    try { await api('/rest/v1/rs2091_inventory',{method:'POST',headers:{Prefer:'return=minimal'},body:payload}); await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('在庫バリエーションを追加しました。'); }
    catch(err){toast(`追加できません: ${err.message}`);}
  }
  async function saveInventory(row) {
    const g=name=>row.querySelector(`[name="${name}"]`).value;
    const payload={sku:g('sku').trim(),size:g('size').trim().toUpperCase(),color:g('color').trim().toUpperCase(),stock:Number(g('stock')),low_stock_threshold:Number(g('low_stock_threshold'))};
    try { await api(`/rest/v1/rs2091_inventory?id=eq.${row.dataset.inventoryRow}`,{method:'PATCH',body:payload}); await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('在庫を更新しました。'); }
    catch(err){toast(`更新できません: ${err.message}`);}
  }
  async function deleteInventory(id) {
    if(!confirm('この在庫バリエーションを削除しますか？'))return;
    try{await api(`/rest/v1/rs2091_inventory?id=eq.${id}`,{method:'DELETE'});await loadAdminData();await loadStore();renderAdminDashboard();toast('在庫を削除しました。');}catch(err){toast(`削除できません: ${err.message}`);}
  }

  // ---------- News ----------
  function renderAdminNews() {
    const section = $('#adminSection');
    const editing = state.adminNews.find(item => item.id === state.editingNewsId) || null;
    const publishedValue = editing?.published_at ? new Date(editing.published_at).toISOString().slice(0, 16) : '';
    section.innerHTML = `<div class="admin-grid">
      <div class="admin-list">
        ${state.adminNews.length ? state.adminNews.map(item => `
          <div class="admin-list-row admin-list-row-text">
            <div class="news-admin-date">${formatDate(item.published_at || item.created_at)}</div>
            <div><div class="admin-row-title">${escapeHTML(item.title)}</div><div class="admin-row-meta">${escapeHTML(item.slug)} / <span class="status-pill ${escapeHTML(item.status)}">${escapeHTML(item.status)}</span><br>${escapeHTML((item.summary || item.body || '').slice(0, 100))}${(item.summary || item.body || '').length > 100 ? '…' : ''}</div></div>
            <div class="admin-row-actions"><button class="mini-button" data-edit-news="${item.id}" type="button">EDIT</button><button class="mini-button danger" data-delete-news="${item.id}" type="button">DELETE</button></div>
          </div>`).join('') : '<div class="admin-message">ニュースがありません。</div>'}
      </div>
      <form id="newsEditor" class="admin-editor">
        <h3>${editing ? 'EDIT NEWS' : 'NEW NEWS'}</h3>
        <div class="admin-editor-grid">
          <input class="form-control" name="title" maxlength="160" placeholder="タイトル" value="${escapeHTML(editing?.title || '')}" required>
          <input class="form-control" name="slug" placeholder="slug" value="${escapeHTML(editing?.slug || '')}" required pattern="[a-z0-9-]+">
          <textarea class="form-control" name="summary" maxlength="260" placeholder="一覧に表示する短い説明">${escapeHTML(editing?.summary || '')}</textarea>
          <textarea class="form-control news-body-input" name="body" placeholder="ニュース本文" required>${escapeHTML(editing?.body || '')}</textarea>
          <div class="inline-grid">
            <select class="form-control" name="status"><option value="draft" ${editing?.status === 'draft' ? 'selected' : ''}>draft</option><option value="published" ${editing?.status === 'published' ? 'selected' : ''}>published</option><option value="archived" ${editing?.status === 'archived' ? 'selected' : ''}>archived</option></select>
            <input class="form-control" name="published_at" type="datetime-local" value="${escapeHTML(publishedValue)}">
          </div>
          <div class="editor-actions"><button class="primary-button" type="submit">${editing ? 'SAVE' : 'CREATE'}</button><button class="secondary-button" id="newsEditorReset" type="button">CLEAR</button></div>
        </div>
      </form>
    </div>`;
    $$('[data-edit-news]').forEach(btn => btn.addEventListener('click', () => { state.editingNewsId = btn.dataset.editNews; renderAdminNews(); }));
    $$('[data-delete-news]').forEach(btn => btn.addEventListener('click', () => deleteNews(btn.dataset.deleteNews)));
    $('#newsEditorReset').addEventListener('click', () => { state.editingNewsId = null; renderAdminNews(); });
    $('#newsEditor').addEventListener('submit', saveNews);
  }

  async function saveNews(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const status = String(fd.get('status'));
    const publishedInput = String(fd.get('published_at') || '');
    const payload = {
      title:String(fd.get('title') || '').trim(),
      slug:String(fd.get('slug') || '').trim().toLowerCase(),
      summary:String(fd.get('summary') || '').trim(),
      body:String(fd.get('body') || '').trim(),
      status,
      published_at:publishedInput ? new Date(publishedInput).toISOString() : (status === 'published' ? new Date().toISOString() : null),
    };
    try {
      if (state.editingNewsId) await api(`/rest/v1/rs2091_news?id=eq.${state.editingNewsId}`, { method:'PATCH', headers:{ Prefer:'return=minimal' }, body:payload });
      else await api('/rest/v1/rs2091_news', { method:'POST', headers:{ Prefer:'return=minimal' }, body:payload });
      state.editingNewsId = null;
      await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('ニュースを保存しました。');
    } catch (err) { toast(`保存できません: ${err.message}`); }
  }

  async function deleteNews(id) {
    if (!confirm('このニュースを削除しますか？')) return;
    try {
      await api(`/rest/v1/rs2091_news?id=eq.${id}`, { method:'DELETE' });
      state.editingNewsId = null;
      await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('ニュースを削除しました。');
    } catch (err) { toast(`削除できません: ${err.message}`); }
  }

  // ---------- Reviews ----------
  function renderAdminReviews() {
    const section=$('#adminSection');
    const editing=state.adminReviews.find(r=>r.id===state.editingReviewId)||null;
    const productOptions=state.adminProducts.map(p=>`<option value="${p.id}" ${editing?.product_id===p.id?'selected':''}>${escapeHTML(p.name)}</option>`).join('');
    section.innerHTML=`<div class="admin-grid">
      <div class="admin-list">${state.adminReviews.map(r=>{const p=state.adminProducts.find(x=>x.id===r.product_id);return `<div class="admin-list-row"><div style="font:16px/1 var(--mono)">${'★'.repeat(Number(r.rating))}</div><div><div class="admin-row-title">${escapeHTML(r.title||'No title')} — ${escapeHTML(r.author_name)}</div><div class="admin-row-meta">${escapeHTML(p?.name||'—')} / <span class="status-pill ${escapeHTML(r.status)}">${escapeHTML(r.status)}</span><br>${escapeHTML(r.body.slice(0,90))}${r.body.length>90?'…':''}</div></div><div class="admin-row-actions"><button class="mini-button" data-edit-review="${r.id}" type="button">EDIT</button><button class="mini-button danger" data-delete-review="${r.id}" type="button">DELETE</button></div></div>`;}).join('')}</div>
      <form id="reviewEditor" class="admin-editor"><h3>${editing?'EDIT REVIEW':'ADD REVIEW'}</h3><div class="admin-editor-grid">
        <select class="form-control" name="product_id" required><option value="">商品を選択</option>${productOptions}</select>
        <input class="form-control" name="author_name" placeholder="投稿者" maxlength="80" value="${escapeHTML(editing?.author_name||'')}" required>
        <div class="inline-grid"><select class="form-control" name="rating">${[5,4,3,2,1].map(n=>`<option value="${n}" ${editing?.rating===n?'selected':''}>${n}</option>`).join('')}</select><select class="form-control" name="status"><option value="pending" ${editing?.status==='pending'?'selected':''}>pending</option><option value="published" ${editing?.status==='published'?'selected':''}>published</option><option value="hidden" ${editing?.status==='hidden'?'selected':''}>hidden</option></select></div>
        <input class="form-control" name="title" placeholder="タイトル" value="${escapeHTML(editing?.title||'')}">
        <textarea class="form-control" name="body" required>${escapeHTML(editing?.body||'')}</textarea>
        <div class="editor-actions"><button class="primary-button" type="submit">${editing?'SAVE':'ADD'}</button><button class="secondary-button" id="reviewEditorReset" type="button">CLEAR</button></div>
      </div></form></div>`;
    $$('[data-edit-review]').forEach(btn=>btn.addEventListener('click',()=>{state.editingReviewId=btn.dataset.editReview;renderAdminReviews();}));
    $$('[data-delete-review]').forEach(btn=>btn.addEventListener('click',()=>deleteReview(btn.dataset.deleteReview)));
    $('#reviewEditorReset').addEventListener('click',()=>{state.editingReviewId=null;renderAdminReviews();});
    $('#reviewEditor').addEventListener('submit',saveReview);
  }
  async function saveReview(e){e.preventDefault();const fd=new FormData(e.currentTarget);const payload={product_id:fd.get('product_id'),author_name:String(fd.get('author_name')).trim(),rating:Number(fd.get('rating')),status:String(fd.get('status')),title:String(fd.get('title')||'').trim(),body:String(fd.get('body')||'').trim()};try{if(state.editingReviewId)await api(`/rest/v1/rs2091_reviews?id=eq.${state.editingReviewId}`,{method:'PATCH',body:payload});else await api('/rest/v1/rs2091_reviews',{method:'POST',body:payload});state.editingReviewId=null;await loadAdminData();await loadStore();renderAdminDashboard();toast('レビューを保存しました。');}catch(err){toast(`保存できません: ${err.message}`);}}
  async function deleteReview(id){if(!confirm('このレビューを削除しますか？'))return;try{await api(`/rest/v1/rs2091_reviews?id=eq.${id}`,{method:'DELETE'});await loadAdminData();await loadStore();renderAdminDashboard();toast('レビューを削除しました。');}catch(err){toast(`削除できません: ${err.message}`);}}

  // ---------- Settings ----------
  function renderAdminSettings() {
    const s = state.adminSettings || {};
    const input = (name, label, value = '', type = 'text') => `<label>${label}<input class="form-control" type="${type}" name="${name}" value="${escapeHTML(value || '')}"></label>`;
    const area = (name, label, value = '') => `<label>${label}<textarea class="form-control" name="${name}">${escapeHTML(value || '')}</textarea></label>`;
    const select = (name, label, value, options) => `<label>${label}<select class="form-control" name="${name}">${options.map(([v,l]) => `<option value="${v}" ${String(value ?? '')===String(v)?'selected':''}>${l}</option>`).join('')}</select></label>`;
    const check = (name, label, value) => `<label class="settings-check"><input type="checkbox" name="${name}" ${value !== false ? 'checked' : ''}> <span>${label}</span></label>`;
    $('#adminSection').innerHTML = `<form id="settingsForm" class="admin-editor admin-settings-editor">
      <h3>HOME / LAYOUT</h3>
      <p class="admin-editor-help">ホームページの文章・表示順・幅・商品列数・セクション表示を変更できます。タイトル欄で改行するとサイトにも反映されます。</p>
      <fieldset class="admin-field-group"><legend>SITE</legend>
        <div class="inline-grid">${input('site_brand', 'BRAND NAME', s.site_brand || 'rs2091')}${input('page_title', 'BROWSER TITLE', s.page_title || 'rs2091 — Official Store')}</div>
        ${area('page_description', 'SEARCH / SHARE DESCRIPTION', s.page_description || '')}
        ${input('announcement', 'ANNOUNCEMENT', s.announcement)}
        <div class="inline-grid">${input('nav_shop_label', 'NAV SHOP', s.nav_shop_label || 'SHOP')}${input('nav_news_label', 'NAV NEWS', s.nav_news_label || 'NEWS')}</div>
        <div class="inline-grid">${input('nav_about_label', 'NAV ABOUT', s.nav_about_label || 'ABOUT')}${input('nav_guide_label', 'NAV GUIDE', s.nav_guide_label || 'GUIDE')}</div>
      </fieldset>
      <fieldset class="admin-field-group"><legend>LAYOUT</legend>
        <div class="inline-grid">${select('layout_preset', 'SECTION ORDER', s.layout_preset || 'standard', [['standard','Standard'],['shop_first','Shop first'],['story_first','Story first']])}${select('content_width', 'PAGE WIDTH', s.content_width || 'standard', [['compact','Compact'],['standard','Standard'],['wide','Wide']])}</div>
        <div class="inline-grid">${select('product_columns', 'PRODUCT COLUMNS (PC)', s.product_columns || 4, [['2','2 columns'],['3','3 columns'],['4','4 columns']])}${select('hero_align', 'HERO ALIGN', s.hero_align || 'left', [['left','Left'],['center','Center']])}</div>
        <div class="settings-check-grid">${check('show_news','Show NEWS',s.show_news)}${check('show_manifesto','Show BRAND MESSAGE',s.show_manifesto)}${check('show_about','Show ABOUT',s.show_about)}${check('show_guide','Show GUIDE',s.show_guide)}</div>
      </fieldset>
      <fieldset class="admin-field-group"><legend>HERO</legend>
        ${input('hero_eyebrow', 'SMALL TITLE', s.hero_eyebrow)}
        ${area('hero_title', 'MAIN TITLE', s.hero_title)}
        ${area('hero_copy', 'TEXT', s.hero_copy)}
        ${input('hero_cta', 'BUTTON LABEL', s.hero_cta)}
      </fieldset>
      <fieldset class="admin-field-group"><legend>SHOP / NEWS</legend>
        <div class="inline-grid">${input('shop_eyebrow', 'SHOP SMALL TITLE', s.shop_eyebrow)}${input('shop_title', 'SHOP TITLE', s.shop_title)}</div>
        <div class="inline-grid">${input('news_eyebrow', 'NEWS SMALL TITLE', s.news_eyebrow)}${input('news_title', 'NEWS TITLE', s.news_title)}</div>
      </fieldset>
      <fieldset class="admin-field-group"><legend>BRAND MESSAGE</legend>
        ${input('manifesto_kicker', 'SMALL TITLE', s.manifesto_kicker)}
        ${area('manifesto_title', 'MAIN MESSAGE', s.manifesto_title)}
        ${input('manifesto_note_1', 'NOTE 1', s.manifesto_note_1)}
        ${input('manifesto_note_2', 'NOTE 2', s.manifesto_note_2)}
        ${input('manifesto_note_3', 'NOTE 3', s.manifesto_note_3)}
      </fieldset>
      <fieldset class="admin-field-group"><legend>ABOUT</legend>
        ${input('about_eyebrow', 'SMALL TITLE', s.about_eyebrow)}
        ${area('about_title', 'TITLE', s.about_title)}
        ${area('about_copy', 'TEXT', s.about_copy)}
      </fieldset>
      <fieldset class="admin-field-group"><legend>GUIDE</legend>
        ${input('shipping_title', 'SHIPPING TITLE', s.shipping_title)}
        ${area('shipping_copy', 'SHIPPING TEXT', s.shipping_copy)}
        ${input('size_title', 'SIZE TITLE', s.size_title)}
        ${area('size_copy', 'SIZE TEXT', s.size_copy)}
        ${input('review_title', 'REVIEW TITLE', s.review_title)}
        ${area('review_copy', 'REVIEW TEXT', s.review_copy)}
      </fieldset>
      <fieldset class="admin-field-group"><legend>FOOTER / CART</legend>
        ${input('instagram_handle', 'INSTAGRAM', s.instagram_handle)}
        ${area('footer_copy', 'FOOTER TEXT', s.footer_copy || '')}
        ${area('cart_note', 'CART NOTE', s.cart_note || '')}
      </fieldset>
      <button class="primary-button" type="submit">SAVE HOME / LAYOUT</button>
    </form>`;
    $('#settingsForm').addEventListener('submit', saveSettings);
  }
  async function saveSettings(e) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const textFields = ['site_brand','page_title','page_description','announcement','nav_shop_label','nav_news_label','nav_about_label','nav_guide_label','layout_preset','content_width','hero_align','hero_eyebrow','hero_title','hero_copy','hero_cta','shop_eyebrow','shop_title','news_eyebrow','news_title','manifesto_kicker','manifesto_title','manifesto_note_1','manifesto_note_2','manifesto_note_3','about_eyebrow','about_title','about_copy','shipping_title','shipping_copy','size_title','size_copy','review_title','review_copy','instagram_handle','footer_copy','cart_note'];
    const payload = Object.fromEntries(textFields.map(key => [key, String(fd.get(key) || '').trim()]));
    payload.product_columns = Number(fd.get('product_columns') || 4);
    for (const key of ['show_news','show_manifesto','show_about','show_guide']) payload[key] = fd.get(key) === 'on';
    try {
      await api('/rest/v1/rs2091_store_settings?id=eq.1', { method:'PATCH', body:payload });
      await loadAdminData(); await loadStore(); renderAdminDashboard(); toast('ホーム文章・レイアウトを保存しました。');
    } catch(err) { toast(`保存できません: ${err.message}`); }
  }

  // ---------- Events / Init ----------
  const page = document.body.dataset.page || 'store';

  if (page === 'admin') {
    hydrateAdminIdentity()
      .then(() => renderAdmin())
      .catch(err => renderAdmin(err.message));
  } else {
    $('#productDialogClose').addEventListener('click',()=>$('#productDialog').close());
    $('#productDialog').addEventListener('click',e=>{if(e.target===$('#productDialog'))$('#productDialog').close();});
    $('#newsDialogClose').addEventListener('click',()=>$('#newsDialog').close());
    $('#newsDialog').addEventListener('click',e=>{if(e.target===$('#newsDialog'))$('#newsDialog').close();});
    $('#cartButton').addEventListener('click',openCart);
    $('#cartClose').addEventListener('click',closeCart);
    $('#cartBackdrop').addEventListener('click',closeCart);
    $('#copyOrderButton').addEventListener('click',copyOrder);
    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeCart();});
    $('#year').textContent = new Date().getFullYear();
    if (location.hash === '#admin') location.replace('/admin/');
    else loadStore();
  }
})();
